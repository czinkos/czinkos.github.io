# Kassák.Digital website

Az oldal teljes egészében statikus fájlokból áll, nincs szerveroldali alkalmazás. Bármelyik szabványos HTTP szerverrel szolgáltatható.

A ```docker-compose.yml``` fájl az egyik hivatalos nginx image-et hivatkozza, és a 8080-as porton publikálja az oldalt.


